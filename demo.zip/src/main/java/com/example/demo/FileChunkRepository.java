package com.example.demo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FileChunkRepository extends JpaRepository<FileChunk, Long> {

    List<FileChunk> findByIdentifierOrderByChunkNumber(String identifier);
    Long countByIdentifier(String identifier);
    Optional<FileChunk> findByIdentifierAndChunkNumber(String identifier, Integer chunkNumber);
    boolean existsByIdentifierAndChunkNumber(String identifier, Integer chunkNumber);

}
