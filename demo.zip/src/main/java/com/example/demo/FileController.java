package com.example.demo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/files")
@CrossOrigin("*")
@Slf4j

public class FileController {

    @Autowired
    private FileUploadService fileUploadService;

    @PostMapping("/upload/chunk")
    public ResponseEntity<?> uploadChunk(
            @RequestParam("file") MultipartFile file,
            @RequestParam("identifier") String identifier,
            @RequestParam("chunkNumber") Integer chunkNumber,
            @RequestParam("totalChunks") Long totalChunks,
            @RequestParam("originalFileName") String originalFileName,
            @RequestParam("totalFileSize") Long totalFileSize) {

        try {
            // Validate request
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("Empty chunk file");
            }

            // Check if chunk already exists
            if (fileUploadService.getFileChunkRepository()
                    .existsByIdentifierAndChunkNumber(identifier, chunkNumber)) {
                return ResponseEntity.ok().body("Chunk already uploaded");
            }

            // Save chunk
            FileChunk savedChunk = fileUploadService.saveChunk(
                    file, identifier, chunkNumber, totalChunks,
                    originalFileName, totalFileSize
            );

            // Check if upload is complete
            if (fileUploadService.isUploadComplete(identifier)) {
                // Combine chunks asynchronously
                CompletableFuture.runAsync(() -> {
                    try {
                        fileUploadService.combineChunks(identifier);
                    } catch (Exception e) {
                        log.error("Error combining chunks for identifier: " + identifier, e);
                    }
                });

                return ResponseEntity.ok().body("All chunks received, processing file");
            }

            return ResponseEntity.ok().body("Chunk uploaded successfully");

        } catch (Exception e) {
            log.error("Error uploading chunk", e);
            return ResponseEntity.internalServerError()
                    .body("Error uploading chunk: " + e.getMessage());
        }
    }

    @GetMapping("/status/{identifier}")
    public ResponseEntity<?> getUploadStatus(@PathVariable String identifier) {
        try {
            Long uploadedChunks = fileUploadService.getFileChunkRepository()
                    .countByIdentifier(identifier);
            List<FileChunk> chunks = fileUploadService.getFileChunkRepository()
                    .findByIdentifierOrderByChunkNumber(identifier);

            if (chunks.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            FileChunk firstChunk = chunks.get(0);
            Map<String, Object> status = new HashMap<>();
            status.put("identifier", identifier);
            status.put("fileName", firstChunk.getOriginalFileName());
            status.put("totalChunks", firstChunk.getTotalChunks());
            status.put("uploadedChunks", uploadedChunks);
            status.put("completed", uploadedChunks.equals(firstChunk.getTotalChunks()));

            return ResponseEntity.ok(status);

        } catch (Exception e) {
            log.error("Error getting upload status", e);
            return ResponseEntity.internalServerError()
                    .body("Error getting upload status: " + e.getMessage());
        }
    }

}
