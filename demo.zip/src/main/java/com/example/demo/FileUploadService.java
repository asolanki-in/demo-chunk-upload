package com.example.demo;

import jakarta.transaction.Transactional;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class FileUploadService {

    @Value("${file.upload.directory}")
    private String uploadDirectory;

    @Getter
    @Autowired
    private FileChunkRepository fileChunkRepository;

    @Transactional
    public FileChunk saveChunk(MultipartFile file, String identifier,
                                     Integer chunkNumber, Long totalChunks,
                                     String originalFileName, Long totalFileSize) throws IOException {

        // Create directories if they don't exist
        String chunkDirectory = uploadDirectory + File.separator + identifier;
        Files.createDirectories(Paths.get(chunkDirectory));

        // Generate chunk path
        String chunkPath = chunkDirectory + File.separator + "chunk_" + chunkNumber;

        // Save the chunk file
        File chunkFile = new File(chunkPath);
        file.transferTo(chunkFile);

        // Save chunk metadata
        FileChunk chunkEntity = new FileChunk();
        chunkEntity.setIdentifier(identifier);
        chunkEntity.setChunkNumber(chunkNumber);
        chunkEntity.setTotalChunks(totalChunks);
        chunkEntity.setOriginalFileName(originalFileName);
        chunkEntity.setChunkPath(chunkPath);
        chunkEntity.setTotalFileSize(totalFileSize);
        chunkEntity.setChunkSize(file.getSize());
        chunkEntity.setUploadDate(LocalDateTime.now());

        return fileChunkRepository.save(chunkEntity);
    }

    @Transactional
    public boolean isUploadComplete(String identifier) {
        Long uploadedChunks = fileChunkRepository.countByIdentifier(identifier);
        List<FileChunk> chunks = fileChunkRepository.findByIdentifierOrderByChunkNumber(identifier);

        if (chunks.isEmpty()) {
            return false;
        }

        return uploadedChunks.equals(chunks.get(0).getTotalChunks());
    }

    @Transactional
    public void combineChunks(String identifier) throws IOException {
        List<FileChunk> chunks = fileChunkRepository.findByIdentifierOrderByChunkNumber(identifier);

        if (chunks.isEmpty()) {
            throw new FileNotFoundException("No chunks found for identifier: " + identifier);
        }

        FileChunk firstChunk = chunks.get(0);
        String outputPath = uploadDirectory + File.separator + firstChunk.getOriginalFileName();
        Path outputFilePath = Paths.get(outputPath);

        // Combine chunks
        try (OutputStream outputStream = Files.newOutputStream(outputFilePath,
                StandardOpenOption.CREATE, StandardOpenOption.WRITE)) {

            byte[] buffer = new byte[8192]; // 8KB buffer

            for (FileChunk chunk : chunks) {
                try (InputStream inputStream = Files.newInputStream(Paths.get(chunk.getChunkPath()))) {
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, bytesRead);
                    }
                }
            }
            outputStream.flush();
        }

        // Verify file size
        long actualFileSize = Files.size(outputFilePath);
        if (actualFileSize != firstChunk.getTotalFileSize()) {
            throw new IOException("Combined file size mismatch. Expected: " +
                    firstChunk.getTotalFileSize() + ", Actual: " + actualFileSize);
        }

        // Update chunk status and clean up
        chunks.forEach(chunk -> {
            chunk.setCompleted(true);
            fileChunkRepository.save(chunk);
            try {
                Files.deleteIfExists(Paths.get(chunk.getChunkPath()));
            } catch (IOException e) {
                log.error("Error deleting chunk file: {}", chunk.getChunkPath(), e);
            }
        });

        // Delete chunk directory
        Files.deleteIfExists(Paths.get(uploadDirectory, identifier));
    }

}
