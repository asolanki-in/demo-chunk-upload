package com.example.demo;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "file_chunks")
@Data
@NoArgsConstructor
public class FileChunk {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String identifier;

    @Column(nullable = false)
    private Integer chunkNumber;

    @Column(nullable = false)
    private Long totalChunks;

    @Column(nullable = false)
    private String originalFileName;

    @Column(nullable = false)
    private String chunkPath;

    @Column(nullable = false)
    private Long totalFileSize;

    private Long chunkSize;

    @Column(nullable = false)
    private LocalDateTime uploadDate;

    private Boolean completed = false;
}
